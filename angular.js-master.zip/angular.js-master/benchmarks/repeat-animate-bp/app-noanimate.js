'use strict';

angular.module('repeatAnimateBenchmark', [])
  .run(function($rootScope) {
    $rootScope.fileType = 'noanimate';
  });
